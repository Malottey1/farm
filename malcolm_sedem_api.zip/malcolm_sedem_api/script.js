function fetchFarmers() {
    fetch('backend/getFarmers.php') // Assuming this is the correct URL to fetch data from the backend
        .then(response => response.json())
        .then(data => {
            const farmersBody = document.getElementById('farmers-list');
            farmersBody.innerHTML = ''; // Clear previous data

            data.forEach(farmer => {
                const row = document.createElement('div');
                row.innerHTML = `
                    <p>ID: ${farmer.id}</p>
                    <p>Name: ${farmer.name}</p>
                    <p>Age: ${farmer.age}</p>
                    <hr>
                `;
                farmersBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching farmers:', error));
}

document.getElementById('get-farmers-btn').addEventListener('click', fetchFarmers);
