<?php
// Include the database connection
require 'dbconn.php';

// Function to fetch data from the "Farmers" table and return it as JSON
function getFarmers() {
    global $conn;

    // SQL query to fetch data from the "Farmers" table
    $sql = "SELECT * FROM Farmers";

    $result = $conn->query($sql);

    // Check if there are any results
    if ($result->num_rows > 0) {
        // Initialize an empty array to store fetched data
        $farmers = array();

        // Fetch associative array
        while ($row = $result->fetch_assoc()) {
            $farmers[] = $row;
        }

        // Encode fetched data as JSON
        $json_output = json_encode($farmers);
        
        // Close connection
        $conn->close();

        // Return JSON data
        return $json_output;
    } else {
        // If no data found, return a message as JSON
        $conn->close();
        return json_encode(array("message" => "No farmers found"));
    }
}

?>
