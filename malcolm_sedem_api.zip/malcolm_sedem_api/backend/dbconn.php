<?php
$host = "127.0.0.1:3306"; 
$dbname = "farm"; 
$username = "pphvgtajzh"; 
$password = "13V34S532584I8CI$"; 

$conn = mysqli_connect($host, $username, $password, $dbname);
if (mysqli_connect_errno()) {
    die("Connection error: " . mysqli_connect_errno());
}
?>
